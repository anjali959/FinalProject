import React from "react";
import "./DeleteConfirmationModal.css";

const DeleteConfirmationModal = ({ task, onCancel, onConfirm }) => {
  if (!task) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <div className="modal-header">
          <h2>Delete</h2>
        </div>
        <div className="modal-body">
          <p>Do you want to delete task <strong>{task.title}</strong>?</p>
        </div>
        <div className="modal-footer">
          <button className="btn cancel" onClick={onCancel}>No</button>
          <button className="btn confirm" onClick={() => onConfirm(task.id)}>Yes</button>
        </div>
      </div>
    </div>
  );
};

export default DeleteConfirmationModal;
