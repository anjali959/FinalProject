import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import "./NewTask.css"; // Same styling as NewTask

const EditTask = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: "",
    assignedTo: "",
    status: "Not Started",
    priority: "Normal",
    dueDate: "",
    description: "",
  });

  useEffect(() => {
    // Load task by ID
    axios
      .get(`http://localhost:4000/api/tasks/${id}`)
      .then((res) => {
        const task = res.data;
        setFormData({
          title: task.title,
          assignedTo: task.assignedTo,
          status: task.status,
          priority: task.priority,
          dueDate: task.createdAt ? task.createdAt.split("T")[0] : "",
          description: task.description,
        });
      })
      .catch((err) => console.error("Failed to load task", err));
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const updatedTask = {
      title: formData.title,
      description: formData.description,
      status: formData.status,
      priority: formData.priority,
      assignedTo: formData.assignedTo,
      createdAt: formData.dueDate,
    };

    try {
      await axios.put(`http://localhost:4000/api/tasks/${id}`, updatedTask);
      navigate("/");
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  return (
    <div className="new-task-container">
      <h2>Edit Task</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Title<span>*</span></label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Assigned To<span>*</span></label>
          <input
            type="text"
            name="assignedTo"
            value={formData.assignedTo}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Status<span>*</span></label>
          <select
            name="status"
            value={formData.status}
            onChange={handleChange}
            required
          >
            <option>Not Started</option>
            <option>In Progress</option>
            <option>Completed</option>
          </select>
        </div>

        <div className="form-group">
          <label>Priority<span>*</span></label>
          <select
            name="priority"
            value={formData.priority}
            onChange={handleChange}
            required
          >
            <option>Low</option>
            <option>Normal</option>
            <option>High</option>
          </select>
        </div>

        <div className="form-group">
          <label>Due Date</label>
          <input
            type="date"
            name="dueDate"
            value={formData.dueDate}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
          />
        </div>

        <div className="form-buttons">
          <button type="button" className="cancel" onClick={() => navigate("/")}>
            Cancel
          </button>
          <button type="submit" className="save">
            Update
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditTask;
