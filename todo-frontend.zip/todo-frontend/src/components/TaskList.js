import './TaskList.css';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DeleteConfirmationModal from './DeleteConfirmationModal'; // ✅ modal import

const TaskList = ({ tasks = [], onDelete, onEdit, refreshTasks }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [pageSize, setPageSize] = useState(20);
  const [taskToDelete, setTaskToDelete] = useState(null); // ✅ state for modal

  const navigate = useNavigate();

  const filteredTasks = tasks.filter(task =>
    task.assignedTo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (id) => {
    onDelete(id);        // calls parent delete
    setTaskToDelete(null); // closes modal
  };

  return (
    <div className="container">
      <h2>Tasks</h2>
      <p className="records-info">{filteredTasks.length} records</p>

      <div className="controls">
        <div className="top-buttons">
          <button className="btn" onClick={() => navigate("/new-task")}>New Task</button>
          <button className="btn" onClick={refreshTasks}>Refresh</button>
        </div>
        <div className="search-box">
          <input
            type="text"
            placeholder="Search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th></th>
            <th>Title</th>
            <th>Assigned To</th>
            <th>Status</th>
            <th>Due Date</th>
            <th>Priority</th>
            <th>Description</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {filteredTasks.map((task) => (
            <tr key={task.id}>
              <td><input type="checkbox" /></td>
              <td>{task.title}</td>
              <td><a href="#">{task.assignedTo}</a></td>
              <td>{task.status}</td>
              <td>{task.createdAt}</td>
              <td>{task.priority}</td>
              <td>{task.description}</td>
              <td>
                <div className="dropdown">
                  <button className="menu-btn">⋮</button>
                  <div className="dropdown-content">
                    <button onClick={() => navigate(`/edit-task/${task.id}`)}>Edit</button>
                    <button onClick={() => setTaskToDelete(task)}>Delete</button> {/* ✅ open modal */}
                  </div>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="pagination">
        <div className="pagination-options">
          <select
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
          >
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
        <div className="pagination-buttons">
          <button className="pagination-btn">{'<< First'}</button>
          <button className="pagination-btn">{'< Prev'}</button>
          <span className="pagination-page">1</span>
          <button className="pagination-btn">{'Next >'}</button>
          <button className="pagination-btn">{'Last >>'}</button>
        </div>
      </div>

      {/* ✅ Delete Confirmation Modal */}
      <DeleteConfirmationModal
        task={taskToDelete}
        onCancel={() => setTaskToDelete(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
};

export default TaskList;
