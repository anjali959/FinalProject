import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import TaskList from "./components/TaskList";
import NewTask from "./components/NewTask";
import EditTask from "./components/EditTask"; // ✅ make sure this exists
import axios from "axios";

function Home() {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = () => {
    axios.get("http://localhost:4000/api/tasks")
      .then((res) => setTasks(res.data))
      .catch((err) => console.error("Fetch error:", err));
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleDelete = (id) => {
    axios.delete(`http://localhost:4000/api/tasks/${id}`)
      .then(() => {
        fetchTasks(); // ✅ refresh the task list after deletion
      })
      .catch((err) => console.error("Delete error:", err));
  };

  return (
    <TaskList
      tasks={tasks}
      refreshTasks={fetchTasks}
      onDelete={handleDelete} // ✅ pass delete handler to TaskList
    />
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/new-task" element={<NewTask />} />
        <Route path="/edit-task/:id" element={<EditTask />} /> {/* ✅ route for editing */}
      </Routes>
    </Router>
  );
}

export default App;
