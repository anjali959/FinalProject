module.exports = {
  HOST: "localhost",
  PORT: 4444,
  USERNAME: "W3_87387_Anjali",
  PASSWORD: "manager",
  DATABASE: "bookshop_db",
  USER_TABLE: "users",
  BOOK_TABLE: "books",
  PURCHASE_TABLE: "purchase",
};
